package org.example.josator2.bedwarmer;

import java.util.Date;

public class Appliance {
	private String name;
	private boolean activated;
	private boolean mode;
	private boolean running;
	private Date Conf_Fijo_Inicio;
	private boolean Enable_Fijo_Final;
	private Date Conf_Fijo_Final;
	private int Conf_Predictivo;


	
	public Appliance(){}
	public Appliance(String name, boolean activated, boolean mode,
			boolean running, Date conf_Fijo_Inicio, boolean enable_Fijo_Final,
			Date conf_Fijo_Final, int conf_Predictivo) {
		super();
		this.name = name;
		this.activated = activated;
		this.mode = mode;
		this.running = running;
		this.Conf_Fijo_Inicio = conf_Fijo_Inicio;
		this.Enable_Fijo_Final = enable_Fijo_Final;
		this.Conf_Fijo_Final = conf_Fijo_Final;
		this.Conf_Predictivo = conf_Predictivo;
	}
	
	public Appliance(String str){
		Date date1=new Date();
		Date date2=new Date();
		String[] lista = str.split(" ");
		String[] listaInicio=lista[5].split(":");
		String[] listaFinal=lista[7].split(":");
		date1.setHours(Integer.parseInt(listaInicio[0]));
		date1.setMinutes(Integer.parseInt(listaInicio[1]));
		date2.setHours(Integer.parseInt(listaFinal[0]));
		date2.setMinutes(Integer.parseInt(listaFinal[1]));
		if(lista[0].equals("Appliance")){
			this.name=lista[1];
			this.activated=(lista[2].equals("true"))?true:false;
			this.mode=(lista[3].equals("true"))?true:false;
			this.running=(lista[4].equals("true"))?true:false;
			this.Conf_Fijo_Inicio=date1;
			this.Enable_Fijo_Final=(lista[6].equals("true"))?true:false;
			this.Conf_Fijo_Final=date2;
			this.Conf_Predictivo=Integer.parseInt(lista[8]);
		}
		else{
			new Appliance();
		}
		
		
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the activated
	 */
	public boolean isActivated() {
		return activated;
	}
	/**
	 * @param activated the activated to set
	 */
	public void setActivated(boolean activated) {
		this.activated = activated;
	}
	/**
	 * @return the mode
	 */
	public boolean isMode() {
		return mode;
	}
	/**
	 * @param mode the mode to set
	 */
	public void setMode(boolean mode) {
		this.mode = mode;
	}
	/**
	 * @return the running
	 */
	public boolean isRunning() {
		return running;
	}
	/**
	 * @param running the running to set
	 */
	public void setRunning(boolean running) {
		this.running = running;
	}
	/**
	 * @return the conf_Fijo_Inicio
	 */
	public Date getConf_Fijo_Inicio() {
		return Conf_Fijo_Inicio;
	}
	/**
	 * @param conf_Fijo_Inicio the conf_Fijo_Inicio to set
	 */
	public void setConf_Fijo_Inicio(Date conf_Fijo_Inicio) {
		Conf_Fijo_Inicio = conf_Fijo_Inicio;
	}
	/**
	 * @return the enable_Fijo_Final
	 */
	public boolean isEnable_Fijo_Final() {
		return Enable_Fijo_Final;
	}
	/**
	 * @param enable_Fijo_Final the enable_Fijo_Final to set
	 */
	public void setEnable_Fijo_Final(boolean enable_Fijo_Final) {
		Enable_Fijo_Final = enable_Fijo_Final;
	}
	/**
	 * @return the conf_Fijo_Final
	 */
	public Date getConf_Fijo_Final() {
		return Conf_Fijo_Final;
	}
	/**
	 * @param conf_Fijo_Final the conf_Fijo_Final to set
	 */
	public void setConf_Fijo_Final(Date conf_Fijo_Final) {
		Conf_Fijo_Final = conf_Fijo_Final;
	}
	/**
	 * @return the conf_Predictivo
	 */
	public int getConf_Predictivo() {
		return Conf_Predictivo;
	}
	/**
	 * @param conf_Predictivo the conf_Predictivo to set
	 */
	public void setConf_Predictivo(int conf_Predictivo) {
		Conf_Predictivo = conf_Predictivo;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Appliance "+ name 
				+ " " + activated
				+ " " + mode 
				+ " " + running
				+ " " + Conf_Fijo_Inicio
				+ " " + Enable_Fijo_Final
				+ " " + Conf_Fijo_Final 
				+ " " + Conf_Predictivo;
	}
	
	
}
