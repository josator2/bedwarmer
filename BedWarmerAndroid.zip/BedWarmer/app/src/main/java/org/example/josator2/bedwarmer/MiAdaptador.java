package org.example.josator2.bedwarmer;


import android.app.TimePickerDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import java.util.Calendar;
import java.util.Date;
import java.util.Vector;

public class MiAdaptador extends BaseExpandableListAdapter{
    private final Context actividad;
    private final Vector<Appliance> lista;
    
    private View[] views;
    
    public MiAdaptador(Context actividad, Vector<Appliance> lista) {
          super();
          this.actividad = actividad;
          this.lista = lista;
          views=new View[2];
    }
    

	@Override
	public int getGroupCount() {
		// TODO Auto-generated method stub
		return lista.size();
	}

	@Override
	public int getChildrenCount(int groupPosition) {
		// TODO Auto-generated method stub
		return 1;
	}

	@Override
	public Object getGroup(int groupPosition) {
		// TODO Auto-generated method stub
		return lista.get(groupPosition);
	}

	@Override
	public Object getChild(int groupPosition, int childPosition) {
		// TODO Auto-generated method stub
		return lista.get(groupPosition);
	}

	@Override
	public long getGroupId(int groupPosition) {
		// TODO Auto-generated method stub
		return groupPosition;
	}

	@Override
	public long getChildId(int groupPosition, int childPosition) {
		// TODO Auto-generated method stub
		return groupPosition;
	}

	@Override
	public boolean hasStableIds() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public View getGroupView(int groupPosition, boolean isExpanded,
			View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		
		if((convertView==null) || (( (int) convertView.getTag())!=groupPosition)) {
            LayoutInflater inflater = (LayoutInflater) actividad.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.elemento_lista, null);
            convertView.setTag(groupPosition);

            CheckBox checkBox1= (CheckBox) convertView.findViewById(R.id.checkbox1);
            checkBox1.setTag(groupPosition);
            checkBox1.setOnCheckedChangeListener(new OnCheckedChangeListener() {

                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    // TODO Auto-generated method stubn
                    Appliance appl = (Appliance) getGroup(Integer.valueOf((int) buttonView.getTag()));
                    if(isChecked){
                        appl.setActivated(true);
                    }
                    else{
                        appl.setActivated(false);
                    }
                    notifyDataSetChanged();
                }
            });
        }

        
        TextView textAppliance= (TextView) convertView.findViewById(R.id.textViewAppliance);
		TextView textMode= (TextView) convertView.findViewById(R.id.textViewMode);
		CheckBox checkBox1= (CheckBox) convertView.findViewById(R.id.checkbox1);
        CheckBox checkBox2= (CheckBox) convertView.findViewById(R.id.checkbox2);
        CheckBox checkBox3= (CheckBox) convertView.findViewById(R.id.checkbox3);

        Appliance appl=(Appliance) getGroup(groupPosition);
        textAppliance.setText(appl.getName());
        checkBox1.setChecked(appl.isActivated());
        checkBox2.setChecked(appl.isMode());
        checkBox3.setChecked(appl.isRunning());
        if(appl.isActivated()){
        	checkBox2.setEnabled(true);
        	checkBox3.setEnabled(true);
        	textAppliance.setEnabled(true);
        	textMode.setEnabled(true);
        	
        }else{
        	checkBox2.setEnabled(false);
        	checkBox3.setEnabled(false);
        	textAppliance.setEnabled(false);
        	textMode.setEnabled(false);
        }

        return convertView;
    
	}

	@Override
	public View getChildView(int groupPosition, int childPosition,
			boolean isLastChild, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		  
		if(convertView==null || (( (int) convertView.getTag())!=groupPosition)){
			LayoutInflater inflater = (LayoutInflater) actividad.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	        convertView = inflater.inflate(R.layout.elemento_subitems, null);
	        convertView.setTag(groupPosition);
	        
	        CheckBox checkBoxFinal = (CheckBox) convertView.findViewById(R.id.checkboxActivateEnd);
	        TextView textViewInitHour= (TextView) convertView.findViewById(R.id.textViewInitHour);
			TextView textViewEndHour= (TextView) convertView.findViewById(R.id.textViewEndHour);
	        
			checkBoxFinal.setTag(groupPosition);
			textViewInitHour.setTag(groupPosition);
			textViewEndHour.setTag(groupPosition);
            checkBoxFinal.setOnCheckedChangeListener(new OnCheckedChangeListener() {

                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    // TODO Auto-generated method stubn
                    Appliance appl = (Appliance) getGroup(Integer.valueOf((int) buttonView.getTag()));
                    if(isChecked){
                        appl.setEnable_Fijo_Final(true);
                    }
                    else{
                    	appl.setEnable_Fijo_Final(false);
                    }
                    notifyDataSetChanged();
                }
             
            });
            textViewInitHour.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					
					Calendar mcurrentTime = Calendar.getInstance();
	                int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
	                int minute = mcurrentTime.get(Calendar.MINUTE);
					final Appliance appl = (Appliance) getGroup(Integer.valueOf((int) v.getTag()));
					TimePickerDialog mTimePicker;
	                mTimePicker = new TimePickerDialog(actividad, new TimePickerDialog.OnTimeSetListener() {
	                    @Override
	                    public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
	                        Date d= new Date();
	                        d.setHours(selectedHour);
	                        d.setMinutes(selectedMinute);
	                        appl.setConf_Fijo_Inicio(d);
	                        notifyDataSetChanged();
	                    }
	                }, hour, minute, true);
	                
	                mTimePicker.setTitle("Select Time");
	                mTimePicker.show();
	                }
				
			});
            
            textViewEndHour.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					
					Calendar mcurrentTime = Calendar.getInstance();
	                int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
	                int minute = mcurrentTime.get(Calendar.MINUTE);
					final Appliance appl = (Appliance) getGroup(Integer.valueOf((int) v.getTag()));
					TimePickerDialog mTimePicker;
	                mTimePicker = new TimePickerDialog(actividad, new TimePickerDialog.OnTimeSetListener() {
	                    @Override
	                    public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
	                        Date d= new Date();
	                        d.setHours(selectedHour);
	                        d.setMinutes(selectedMinute);
	                        appl.setConf_Fijo_Final(d);
	                        notifyDataSetChanged();
	                    }
	                }, hour, minute, true);
	                
	                mTimePicker.setTitle("Select Time");
	                mTimePicker.show();
	                }
				
			});
            
    	  }
		 CheckBox checkBoxFinal = (CheckBox) convertView.findViewById(R.id.checkboxActivateEnd);
		 TextView textViewInitHour= (TextView) convertView.findViewById(R.id.textViewInitHour);
		 TextView textViewEndHour= (TextView) convertView.findViewById(R.id.textViewEndHour);
		 TextView textViewEnd= (TextView) convertView.findViewById(R.id.textViewEn);
		 EditText editTextPredictorTime= (EditText) convertView.findViewById(R.id.editTextPredictorTime);
		 Appliance appl=(Appliance) getGroup(groupPosition);
		 
		 int hour = appl.getConf_Fijo_Inicio().getHours();
		 int minute = appl.getConf_Fijo_Inicio().getMinutes();
		 String sHour = (hour<10)?"0"+hour:""+hour;
		 String sMinute = (minute<10)?"0"+minute:""+minute;
		 textViewInitHour.setText(sHour+":"+sMinute);
		 
		 hour = appl.getConf_Fijo_Final().getHours();
		 minute = appl.getConf_Fijo_Final().getMinutes();
		 sHour = (hour<10)?"0"+hour:""+hour;
		 sMinute = (minute<10)?"0"+minute:""+minute;
		 textViewEndHour.setText(sHour+":"+sMinute);
		 
		 
		 
		 if (appl.isEnable_Fijo_Final()){
			 textViewEnd.setEnabled(true);
			 textViewEndHour.setEnabled(true);
		 }else {
			 textViewEnd.setEnabled(false);
			 textViewEndHour.setEnabled(false);
		}
		 
		
		
		return convertView;
	}

	@Override
	public boolean isChildSelectable(int groupPosition, int childPosition) {
		// TODO Auto-generated method stub
		return false;
	}

}
