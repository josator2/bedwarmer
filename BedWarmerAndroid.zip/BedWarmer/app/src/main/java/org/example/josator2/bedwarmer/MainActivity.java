package org.example.josator2.bedwarmer;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ExpandableListView;

import java.util.Vector;

public class MainActivity extends ListActivity {
	private StorageAppliance appliances;
	MiAdaptador miadap;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		appliances=new StorageApplianceArray();
		Vector<Appliance> v=appliances.listAppliance(10);
		miadap=new MiAdaptador(this, v);
		ExpandableListView exList = (ExpandableListView) findViewById(android.R.id.list);  
		exList.setAdapter(miadap);
		exList.setIndicatorBounds(0, 20);

	}
	
	public boolean onCreateOptionsMenu(Menu menu) {
	       getMenuInflater().inflate(R.menu.menu_main, menu);
	       return true; /** true -> el men� ya est� visible */
	}
	public boolean onOptionsItemSelected(MenuItem item) {
	       switch (item.getItemId()) {
	       case R.id.Help:
	             launchHelp(null);
	             break;
	     
	       }
	       return true; /** true -> consumimos el item, no se propaga*/
	}
	
	public void launchHelp(View view) {
	       Intent i = new Intent(this, HelpActivity.class);
	       startActivity(i);
	}
}
