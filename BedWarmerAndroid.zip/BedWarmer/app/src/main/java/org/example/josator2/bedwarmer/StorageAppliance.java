package org.example.josator2.bedwarmer;

import java.util.Vector;

public interface StorageAppliance {
	public void createAppliance(Appliance appliance);
	public void editAppliance(Appliance appliance, int pos);
	public Vector<Appliance> listAppliance(int cantidad);
	public Appliance getAppliance(int pos);
	public int size();
}
