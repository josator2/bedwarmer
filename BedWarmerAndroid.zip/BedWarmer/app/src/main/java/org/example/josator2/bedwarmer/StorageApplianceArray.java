package org.example.josator2.bedwarmer;

import java.util.Date;
import java.util.Vector;

public class StorageApplianceArray implements StorageAppliance {
	private Vector<Appliance> appliances;
	
	
	/**
	 * 
	 */
	public StorageApplianceArray() {
		super();
		appliances=new Vector<Appliance>();
		Appliance appliance1=new Appliance("Cafetera", false, false, false, new Date(), false, new Date(), 5);
		Appliance appliance2=new Appliance("Aire Acondicionado", false, false, false, new Date(), false, new Date(), 20);
		appliances.add(appliance1);
		appliances.add(appliance2);
	
	}

	@Override
	public void createAppliance(Appliance appliance) {
		// TODO Auto-generated method stub
		appliances.add(appliance);
	}

	@Override
	public void editAppliance(Appliance appliance, int pos) {
		// TODO Auto-generated method stub
		appliances.setElementAt(appliance, pos);
	}

	@Override
	public Vector<Appliance> listAppliance(int cantidad) {
		// TODO Auto-generated method stub
		return appliances;
	}

	@Override
	public Appliance getAppliance(int pos) {
		// TODO Auto-generated method stub
		return appliances.get(pos);
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return appliances.size();
	}

}
