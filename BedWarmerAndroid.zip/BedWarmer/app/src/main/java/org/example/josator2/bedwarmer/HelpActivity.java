package org.example.josator2.bedwarmer;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by josator2 on 1/03/15.
 */
public class HelpActivity extends Activity{

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.help);
    }
}
